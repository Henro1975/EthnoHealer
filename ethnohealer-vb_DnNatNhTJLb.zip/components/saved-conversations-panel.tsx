"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Trash2, MessageSquare, Plus } from "lucide-react"
import type { SavedConversation } from "@/lib/types"
import type { LanguageCode } from "@/lib/translations"
import { translations } from "@/lib/translations"
import { formatDistanceToNow } from "date-fns"

interface SavedConversationsPanelProps {
  conversations: SavedConversation[]
  onLoad: (conversation: SavedConversation) => void
  onDelete: (id: string) => void
  onNewChat: () => void
  language: LanguageCode
  currentConversationId: string | null
}

export function SavedConversationsPanel({
  conversations,
  onLoad,
  onDelete,
  onNewChat,
  language,
  currentConversationId,
}: SavedConversationsPanelProps) {
  const t = translations[language]

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation()
    if (window.confirm(t.confirmDelete)) {
      onDelete(id)
    }
  }

  return (
    <div className="w-64 border-r bg-gray-50 flex flex-col h-full">
      <div className="p-4 border-b bg-white">
        <Button onClick={onNewChat} className="w-full" variant="default">
          <Plus size={16} className="mr-2" />
          {t.newChat}
        </Button>
      </div>

      <div className="p-3 border-b bg-white">
        <h3 className="font-semibold text-sm text-gray-700">{t.savedConversations}</h3>
      </div>

      <ScrollArea className="flex-1">
        {conversations.length === 0 ? (
          <div className="p-4 text-center text-sm text-gray-500">{t.noSavedConversations}</div>
        ) : (
          <div className="p-2 space-y-1">
            {conversations.map((conv) => (
              <div
                key={conv.id}
                className={`group p-3 rounded-lg cursor-pointer transition-colors hover:bg-white border ${
                  currentConversationId === conv.id ? "bg-white border-green-500" : "bg-gray-50 border-transparent"
                }`}
                onClick={() => onLoad(conv)}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <MessageSquare size={14} className="text-gray-500 flex-shrink-0" />
                      <h4 className="text-sm font-medium text-gray-900 truncate">{conv.title}</h4>
                    </div>
                    <p className="text-xs text-gray-500">{formatDistanceToNow(conv.updatedAt, { addSuffix: true })}</p>
                    <p className="text-xs text-gray-400 mt-1">{conv.messages.length} messages</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 flex-shrink-0"
                    onClick={(e) => handleDelete(e, conv.id)}
                  >
                    <Trash2 size={14} className="text-red-500" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  )
}
