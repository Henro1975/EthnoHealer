"use client"

import { useState, useEffect } from "react"
import { DEFAULT_LANGUAGE, LANGUAGES } from "@/lib/app-config"
import type { LanguageCode } from "@/lib/translations"

const STORAGE_KEY = "ethnohealer_language"

export const useLanguage = () => {
  const [language, setLanguageState] = useState<LanguageCode>(DEFAULT_LANGUAGE as LanguageCode)

  // Load language from localStorage on mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem(STORAGE_KEY)
    if (savedLanguage && LANGUAGES.some((lang) => lang.code === savedLanguage)) {
      setLanguageState(savedLanguage as LanguageCode)
    }
  }, [])

  // Save language to localStorage when it changes
  const setLanguage = (newLanguage: LanguageCode) => {
    setLanguageState(newLanguage)
    localStorage.setItem(STORAGE_KEY, newLanguage)
  }

  return {
    language,
    setLanguage,
  }
}
