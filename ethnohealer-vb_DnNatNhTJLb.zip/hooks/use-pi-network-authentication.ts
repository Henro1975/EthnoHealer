"use client"

import { useState, useEffect } from "react"
import { PI_NETWORK_CONFIG, BACKEND_URLS } from "@/lib/app-config"
import { translations, type LanguageCode } from "@/lib/translations"

// Function to dynamically load Pi SDK script
const loadPiSDK = (): Promise<void> => {
  return new Promise((resolve, reject) => {
    const script = document.createElement("script")
    script.src = PI_NETWORK_CONFIG.SDK_URL
    script.async = true

    script.onload = () => {
      console.info("✅ Pi SDK script loaded successfully")
      resolve()
    }

    script.onerror = () => {
      console.error("❌ Failed to load Pi SDK script")
      reject(new Error("Failed to load Pi SDK script"))
    }

    document.head.appendChild(script)
  })
}

export const usePiNetworkAuthentication = (language: LanguageCode = "en") => {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [authMessage, setAuthMessage] = useState("Initializing Pi Network...")
  const [piAccessToken, setPiAccessToken] = useState<string | null>(null)

  const t = translations[language]

  const authenticateAndLogin = async (): Promise<void> => {
    setAuthMessage(t.authenticating)
    console.log("Starting authentication...")
    const piAuthResult = await window.Pi.authenticate(["username", "roles"])

    setAuthMessage(t.loggingIn)
    const loginRes = await fetch(BACKEND_URLS.LOGIN, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pi_auth_token: piAuthResult.accessToken }),
    })

    if (!loginRes.ok) {
      throw new Error(`Backend login failed with status: ${loginRes.status}`)
    }

    await loginRes.json()
    console.info("✅ Backend login successful")

    if (piAuthResult?.accessToken) {
      setPiAccessToken(piAuthResult.accessToken)
    }
  }

  const initializePiAndAuthenticate = async () => {
    try {
      // Step 1: Load Pi SDK script
      setAuthMessage(t.loadingSDK)
      await loadPiSDK()

      // Step 2: Verify Pi object is available
      if (typeof window.Pi === "undefined") {
        throw new Error("Pi object not available after script load")
      }

      // Step 3: Initialize Pi Network
      setAuthMessage(t.initializing)
      await window.Pi.init({ version: "2.0", sandbox: PI_NETWORK_CONFIG.SANDBOX })

      // Step 4: Authenticate and login
      await authenticateAndLogin()

      // Step 5: Success
      setIsAuthenticated(true)
    } catch (err) {
      console.error("❌ Pi Network initialization failed:", err)
      setAuthMessage(t.authFailed)
    }
  }

  useEffect(() => {
    initializePiAndAuthenticate()
  }, [])

  return {
    isAuthenticated,
    authMessage,
    piAccessToken,
    reinitialize: initializePiAndAuthenticate,
  }
}
