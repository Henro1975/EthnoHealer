"use client"

import { useState, useEffect } from "react"
import type { SavedConversation, Message } from "@/lib/types"
import type { LanguageCode } from "@/lib/translations"

const STORAGE_KEY = "ethnohealer_saved_conversations"

export const useSavedConversations = () => {
  const [savedConversations, setSavedConversations] = useState<SavedConversation[]>([])

  // Load saved conversations from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY)
    if (stored) {
      try {
        const parsed = JSON.parse(stored)
        // Convert date strings back to Date objects
        const conversations = parsed.map((conv: any) => ({
          ...conv,
          createdAt: new Date(conv.createdAt),
          updatedAt: new Date(conv.updatedAt),
          messages: conv.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp),
          })),
        }))
        setSavedConversations(conversations)
      } catch (error) {
        console.error("[v0] Error loading saved conversations:", error)
      }
    }
  }, [])

  // Save conversations to localStorage whenever they change
  const persistConversations = (conversations: SavedConversation[]) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations))
    } catch (error) {
      console.error("[v0] Error saving conversations:", error)
    }
  }

  const saveConversation = (messages: Message[], language: LanguageCode): string => {
    // Generate title from first user message or use default
    const firstUserMessage = messages.find((m) => m.sender === "user")
    const title = firstUserMessage ? firstUserMessage.text.slice(0, 50) : "New Conversation"

    const newConversation: SavedConversation = {
      id: Date.now().toString(),
      title,
      messages,
      createdAt: new Date(),
      updatedAt: new Date(),
      language,
    }

    const updated = [newConversation, ...savedConversations]
    setSavedConversations(updated)
    persistConversations(updated)

    return newConversation.id
  }

  const deleteConversation = (id: string) => {
    const updated = savedConversations.filter((conv) => conv.id !== id)
    setSavedConversations(updated)
    persistConversations(updated)
  }

  const loadConversation = (id: string): SavedConversation | undefined => {
    return savedConversations.find((conv) => conv.id === id)
  }

  const updateConversation = (id: string, messages: Message[]) => {
    const updated = savedConversations.map((conv) =>
      conv.id === id
        ? {
            ...conv,
            messages,
            updatedAt: new Date(),
          }
        : conv,
    )
    setSavedConversations(updated)
    persistConversations(updated)
  }

  return {
    savedConversations,
    saveConversation,
    deleteConversation,
    loadConversation,
    updateConversation,
  }
}
