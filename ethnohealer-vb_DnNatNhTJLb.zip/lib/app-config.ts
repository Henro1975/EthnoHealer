// *** Configurable variables for the app ***
// This file contains all the user-editable configuration values that can be updated when customizing the chatbot app.

export const APP_CONFIG = {
  // UPDATE: Set to the welcome message for the chatbot
  WELCOME_MESSAGE:
    "Welcome to EthnoHealer! Discover global traditional remedies, plants, and spiritual practices for well-being. How can I help you?",

  // UPDATE: Set to the name of the chatbot app
  NAME: "EthnoHealer",

  // UPDATE: Set to the description of the chatbot app
  DESCRIPTION: "EthnoHealer is your guide to traditional and natural remedies. Explore the medicinal properties of plants, animals, and spiritual practices, rooted in ethnomedicine and holistic well-being.",
} as const;

// Colors Configuration - UPDATE THESE VALUES BASED ON USER DESIGN PREFERENCES
export const COLORS = {
  // UPDATE: Set to the background color (hex format)
  BACKGROUND: "#0000ff",

  // UPDATE: Set to the primary color for buttons, links, etc. (hex format)
  PRIMARY: "#00ff00",
} as const;
